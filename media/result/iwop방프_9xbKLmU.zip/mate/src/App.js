import './App.css';
import logo from './img/logo.png'
import banner from './img/banner.png'
import search from './img/search.png'
import footerlogo from './img/footerlogo.png'

function App() {
  return (
    <div className="header">
      <div className='nav'>
        <span className='logo'><img src = {logo}/></span>
        <span className='left'>Home</span>
        <span className='left'>About</span>
        <span className='right'>Mating</span>
        <span className='right'>Mating chat</span>
        <span className='right'>New mating</span>
        <span className='right2'>Log in&nbsp;&nbsp;·</span>
        <span className='right2'>&nbsp;&nbsp;Sign up</span>
      </div>

      <div>
        <span className='banner'><img src = {banner}/></span>
      </div>

      <div>
        <button className='residence'>Residence<img className='search' src = {search}/></button>
      </div>

      <div className='footer'>
        <span className='footerlogo'><img src = {footerlogo}/></span>
        <span className='technology'>Technology</span>
        <span className='location'>Location</span>
        <span className='contact'>Contact</span>
      </div>

      <div className='footercontent'>
        <span>Mate sensor only finds<br/>
          same-sex friends to live<br/>
          with you.
        </span>

      </div>
    </div>

  );
}

export default App;
