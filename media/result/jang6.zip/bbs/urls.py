from django.urls import path
from . import views

urlpatterns = [
    path('', views.bbs_list, name='bbs_list'),
    path('bbs/<int:pk>/', views.bbs_detail, name='bbs_detail'),
    path('bbs/new/', views.bbs_post, name='bbs_post'),
    path('bbs/<int:pk>/edit', views.bbs_edit, name='bbs_edit'),
]
