from django import forms
from .models import Question, Answer
class QuestionForm(forms.ModelForm):
    class Meta: 
        model = Question
        fields = ['subject', 'content']
        labels = {
            'subject': '제목',
            'content': '내용',
        } 
