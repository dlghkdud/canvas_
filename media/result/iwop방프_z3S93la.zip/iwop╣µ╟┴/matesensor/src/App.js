import './App.css';
import logo from './img/logo.png'

function App() {
  return (
    <div className="header">
      <div className='nav'>
        <span><img src = {logo}/></span>
        <span className='span0'>Home</span>
        <span>About</span>
        <span className='span1'>Mating</span>
        <span className='span2'>Mating chat</span>
        <span className='span2'>New mating</span>
        <span className='span3'>Log in&nbsp;&nbsp;·</span>
        <span className='span3'>&nbsp;&nbsp;Sign up</span>
      </div>
    </div>
  );
}

export default App;
