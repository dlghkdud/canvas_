from django.shortcuts import render, get_object_or_404, redirect
from .models import Bbs
from .form import BbsForm

# Create your views here.
def bbs_list(request):
    bbs = Bbs.objects.all()
    return render(request, 'bbs/bbs_list.html', {'bbss':bbs})

def bbs_detail(request, pk):
    bbs = get_object_or_404(Bbs, pk=pk)
    return render(request, 'bbs/bbs_detail.html', {'bbs':bbs})

def bbs_edit(request, pk):
    bbs = get_object_or_404(Bbs, pk=pk)
    if request.method == "POST":
        form = BbsForm(request.POST, instance=bbs)
        if form.is_valid():
            bbs = form.save(commit=False)
            bbs.save()
            return redirect('bbs_detail', pk=bbs.pk)
    else:
        form = BbsForm(instance=bbs)
    return render(request, 'bbs/bbs_post.html', {'form':form})

def bbs_post(request):
    if request.method == "POST":
        form = BbsForm(request.POST)
        if form.is_valid():
            bbs = form.save(commit=False)
            bbs.save()
            return redirect('bbs_detail', pk=bbs.pk)
    else:
        form = BbsForm()
        return render(request, 'bbs/bbs_post.html', {'form':form})