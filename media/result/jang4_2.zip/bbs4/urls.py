from django.urls import path
from . import views

urlpatterns = [
    path('', views.bbs_list, name= 'bbs_list'),
    path('bbs4/<int:pk>/', views.bbs_detail, name= 'bbs_detail'),
    path('bbs4/<int:pk>/edit', views.bbs_edit, name= 'bbs_edit'),
    path('photo4/new/', views.bbs_post, name= 'bbs_post'),
]
