from django.contrib import admin
from .models import Bbs

# Register your models here.
admin.site.register(Bbs)